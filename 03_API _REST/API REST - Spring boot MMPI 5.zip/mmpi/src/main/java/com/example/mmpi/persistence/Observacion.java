package com.example.mmpi.persistence;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "OBSERVACION")
public class Observacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_OBSERVACION")
    private Integer idObservacion;

    @Column(name = "DNI_PACIENTE", nullable = false, length = 50)
    private String dniPaciente;

    @Column(name = "TIPO_PERIODO", nullable = false, length = 20)
    private String tipoPeriodo;

    @Column(name = "FECHA_INICIO")
    private LocalDate fechaInicio;

    @Column(name = "FECHA_FIN")
    private LocalDate fechaFin;

    @Column(name = "CLAVE_PERIODO", nullable = false, length = 100)
    private String clavePeriodo;

    @Column(name = "TEXTO", nullable = false, columnDefinition = "TEXT")
    private String texto;

    @Column(name = "FECHA_CREACION", insertable = false, updatable = false)
    private LocalDateTime fechaCreacion;

    @Column(name = "FECHA_ACTUALIZACION", insertable = false, updatable = false)
    private LocalDateTime fechaActualizacion;

    public Observacion() {
    	
    }

    public Integer getIdObservacion() {
        
    	return idObservacion;
    
    }

    public void setIdObservacion(Integer idObservacion) {
    
    	this.idObservacion = idObservacion;
    
    }

    public String getDniPaciente() {
    
    	return dniPaciente;
    
    }

    public void setDniPaciente(String dniPaciente) {
    
    	this.dniPaciente = dniPaciente;
    
    }

    public String getTipoPeriodo() {
    
    	return tipoPeriodo;
    
    }

    public void setTipoPeriodo(String tipoPeriodo) {
    
    	this.tipoPeriodo = tipoPeriodo;
    
    }

    public LocalDate getFechaInicio() {
    
    	return fechaInicio;
    
    }

    public void setFechaInicio(LocalDate fechaInicio) {
    
    	this.fechaInicio = fechaInicio;
    
    }

    public LocalDate getFechaFin() {
    
    	return fechaFin;
    
    }

    public void setFechaFin(LocalDate fechaFin) {
    
    	this.fechaFin = fechaFin;
    
    }

    public String getClavePeriodo() {
    
    	return clavePeriodo;
    
    }

    public void setClavePeriodo(String clavePeriodo) {
    
    	this.clavePeriodo = clavePeriodo;
    
    }

    public String getTexto() {
    
    	return texto;
    
    }

    public void setTexto(String texto) {
    
    	this.texto = texto;
    
    }

    public LocalDateTime getFechaCreacion() {
    
    	return fechaCreacion;
    
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
    
    	this.fechaCreacion = fechaCreacion;
    
    }

    public LocalDateTime getFechaActualizacion() {
    
    	return fechaActualizacion;
    
    }

    public void setFechaActualizacion(LocalDateTime fechaActualizacion) {
    
    	this.fechaActualizacion = fechaActualizacion;
    
    }

}