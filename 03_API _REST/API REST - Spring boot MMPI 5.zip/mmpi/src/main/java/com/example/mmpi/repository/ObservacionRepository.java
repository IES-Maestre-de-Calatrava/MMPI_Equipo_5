package com.example.mmpi.repository;

import com.example.mmpi.persistence.Observacion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ObservacionRepository extends JpaRepository<Observacion, Integer> {

    Optional<Observacion> findByDniPacienteAndTipoPeriodoAndClavePeriodo(
            String dniPaciente,
            String tipoPeriodo,
            String clavePeriodo
    );

    List<Observacion> findByDniPacienteOrderByFechaActualizacionDesc(String dniPaciente);

    List<Observacion> findByDniPacienteAndTipoPeriodoOrderByFechaActualizacionDesc(
            String dniPaciente,
            String tipoPeriodo
    );
}