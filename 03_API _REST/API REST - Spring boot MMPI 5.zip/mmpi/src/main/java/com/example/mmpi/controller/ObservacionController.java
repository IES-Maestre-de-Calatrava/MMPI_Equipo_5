package com.example.mmpi.controller;

import com.example.mmpi.persistence.Observacion;
import com.example.mmpi.repository.ObservacionRepository;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/observacion")
@CrossOrigin(origins = "*")
public class ObservacionController {

    private final ObservacionRepository observacionRepository;

    public ObservacionController(ObservacionRepository observacionRepository) {
    	
        this.observacionRepository = observacionRepository;
    
    }

    @GetMapping("/find")
    public ResponseEntity<?> findObservaciones(
            @RequestParam(required = false) String dniPaciente,
            @RequestParam(required = false) String tipoPeriodo,
            @RequestParam(required = false) String clavePeriodo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin
    
    		) {

        if (dniPaciente == null || dniPaciente.trim().isEmpty()) {
            
        	return ResponseEntity.ok(observacionRepository.findAll());
        
        }

        if (tipoPeriodo == null || tipoPeriodo.trim().isEmpty()) {
        
        	List<Observacion> observaciones = observacionRepository
           
        			.findByDniPacienteOrderByFechaActualizacionDesc(dniPaciente);

            return ResponseEntity.ok(observaciones);
        
        }

        String tipoNormalizado = tipoPeriodo.trim().toUpperCase();

        if (clavePeriodo == null || clavePeriodo.trim().isEmpty()) {
        
        	clavePeriodo = crearClavePeriodo(tipoNormalizado, fechaInicio, fechaFin);
        
        }

        if (clavePeriodo == null || clavePeriodo.trim().isEmpty()) {
        
        	List<Observacion> observaciones = observacionRepository
           
        			.findByDniPacienteAndTipoPeriodoOrderByFechaActualizacionDesc(dniPaciente, tipoNormalizado);

            return ResponseEntity.ok(observaciones);
        
        }

        Optional<Observacion> observacion = observacionRepository
        
        		.findByDniPacienteAndTipoPeriodoAndClavePeriodo(
              
        				dniPaciente,
                        tipoNormalizado,
                        clavePeriodo
                
        				);

        if (observacion.isPresent()) {
            
        	return ResponseEntity.ok(observacion.get());
        
        }

        Observacion vacia = new Observacion();
        vacia.setDniPaciente(dniPaciente);
        vacia.setTipoPeriodo(tipoNormalizado);
        vacia.setFechaInicio(fechaInicio);
        vacia.setFechaFin(fechaFin);
        vacia.setClavePeriodo(clavePeriodo);
        vacia.setTexto("");

        return ResponseEntity.ok(vacia);
    
    }

    @PostMapping("/save")
    @Transactional
    public ResponseEntity<?> saveObservacion(@RequestBody Observacion observacion) {

        if (observacion.getDniPaciente() == null || observacion.getDniPaciente().trim().isEmpty()) {
    
        	return ResponseEntity.badRequest().body("El DNI del paciente es obligatorio.");
        
        }

        if (observacion.getTipoPeriodo() == null || observacion.getTipoPeriodo().trim().isEmpty()) {
        
        	return ResponseEntity.badRequest().body("El tipo de periodo es obligatorio.");
        
        }

        if (observacion.getTexto() == null) {
        
        	observacion.setTexto("");
        
        }

        String tipoNormalizado = observacion.getTipoPeriodo().trim().toUpperCase();
        observacion.setTipoPeriodo(tipoNormalizado);

        if (!tipoNormalizado.equals("DIA") &&
        
        		!tipoNormalizado.equals("SEMANA") &&
            
        		!tipoNormalizado.equals("GLOBAL")) {

            return ResponseEntity.badRequest().body("El tipo de periodo debe ser DIA, SEMANA o GLOBAL.");
        
        }

        String clavePeriodo = observacion.getClavePeriodo();

        if (clavePeriodo == null || clavePeriodo.trim().isEmpty()) {
        
        	clavePeriodo = crearClavePeriodo(
            
        			tipoNormalizado,
                    observacion.getFechaInicio(),
                    observacion.getFechaFin()
            
        			);
        
        }

        if (clavePeriodo == null || clavePeriodo.trim().isEmpty()) {
        
        	return ResponseEntity.badRequest().body("No se pudo calcular la clave del periodo.");
        
        }

        observacion.setClavePeriodo(clavePeriodo);

        Optional<Observacion> existente = observacionRepository
        
        		.findByDniPacienteAndTipoPeriodoAndClavePeriodo(
                
        				observacion.getDniPaciente(),
                        observacion.getTipoPeriodo(),
                        observacion.getClavePeriodo()
                
        				);

        if (existente.isPresent()) {

        	Observacion observacionExistente = existente.get();

            observacionExistente.setTexto(observacion.getTexto());
            observacionExistente.setFechaInicio(observacion.getFechaInicio());
            observacionExistente.setFechaFin(observacion.getFechaFin());

            Observacion guardada = observacionRepository.save(observacionExistente);

            return ResponseEntity.ok(guardada);

        }

        Observacion guardada = observacionRepository.save(observacion);

        return ResponseEntity.ok(guardada);
    
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteObservacion(@PathVariable Integer id) {

        if (!observacionRepository.existsById(id)) {
    
        	return ResponseEntity.notFound().build();
        
        }

        observacionRepository.deleteById(id);

        return ResponseEntity.ok("Observación eliminada correctamente.");
    
    }

    private String crearClavePeriodo(String tipoPeriodo, LocalDate fechaInicio, LocalDate fechaFin) {

    
    	if (tipoPeriodo == null) {
        
    		return null;
        
    	}

        if (tipoPeriodo.equals("GLOBAL")) {
            
        	return "GLOBAL";
        
        }

        if (tipoPeriodo.equals("DIA")) {

            if (fechaInicio == null) {
        
            	return null;
            
            }

            return fechaInicio.toString();
        
        }

        if (tipoPeriodo.equals("SEMANA")) {

            if (fechaInicio == null || fechaFin == null) {
        
            	return null;
            
            }

            return fechaInicio + "_" + fechaFin;
        
        }

        return null;
    
    }

}